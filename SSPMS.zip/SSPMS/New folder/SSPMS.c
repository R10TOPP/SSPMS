sbit LCD_RS at RD2_bit;
sbit LCD_EN at RD3_bit;
sbit LCD_D4 at RD4_bit;
sbit LCD_D5 at RD5_bit;
sbit LCD_D6 at RD6_bit;
sbit LCD_D7 at RD7_bit;
sbit LCD_RS_Direction at TRISD2_bit;
sbit LCD_EN_Direction at TRISD3_bit;
sbit LCD_D4_Direction at TRISD4_bit;
sbit LCD_D5_Direction at TRISD5_bit;
sbit LCD_D6_Direction at TRISD6_bit;
sbit LCD_D7_Direction at TRISD7_bit;

void ATD_init(void);
unsigned int ATD_read(void);


 float temperature1;
  int temperature2;
     int v;

char Temperature[] = " 00.0 C";
char ds[] = " 000 cm";
unsigned int temp;
void usDelay(unsigned int);
void msDelay(unsigned int);

void main() {

  TRISB = 0xC3;                // 11000011
  TRISD = 0x00;               // 00000000 Output
  T1CON = T1CON & 0x0F;      //using internal clock fosc/4 & setting T1CKPS0 and T1CKPS1 to 0
 Lcd_Init();
 Lcd_Cmd(_LCD_CLEAR);
 Lcd_Cmd(_LCD_CURSOR_OFF);
 PORTB =0x08;                // Pin 3, turn off relay -> turn off actuator
 msDelay(2000);



ATD_init();

  while(1){
int distance = 0;
int T1=0;
TMR1L = 0;
TMR1H  = 0;
PORTD=0x02;
usDelay(10);
PORTD=0x00;

while (!(PORTB & 0x01)){}     //check if PORTB, bit 0 is cleared, and keeps looping as long as it is
T1CON = T1CON | 0x01;         //TURN ON TMR1
while (PORTB & 0x01){}        // check if PORTB, bit 0 is set, and keeps looping as long as it is
T1CON = T1CON & 0xFE;        //TURN OFF TMR1
T1 =  (TMR1H<<8) | (TMR1L) ;
distance = T1/117.64;       // calculate distance from sound speed and time calculated using timer1


if(distance>17){            // Change Water Level Threshold, if above then turn on the actuator to fill up the pool
   PORTB=0x00;
}

else {
   PORTB =0x08;
}


if(distance>=30){
       lcd_Out(1, 1, "Tank:  0% Filled");
}

if(distance>=28 && distance<30){
       lcd_Out(1, 1, "Tank: 10% Filled");
}


if(distance>=26 && distance<28){
       lcd_Out(1, 1, "Tank: 20% Filled");
}


if(distance>=24 && distance<26){
       lcd_Out(1, 1, "Tank: 30% Filled");
}


if(distance>=22 && distance<24){
       lcd_Out(1, 1, "Tank: 40% Filled");
}



if(distance>=20 && distance<22){
       lcd_Out(1, 1, "Tank: 50% Filled");
}



if(distance>=18 && distance<20){
       lcd_Out(1, 1, "Tank: 60% Filled");
}



if(distance>=16 && distance<18){
       lcd_Out(1, 1, "Tank: 70% Filled");
}


if(distance>=14 && distance<16){
       lcd_Out(1, 1, "Tank: 80% Filled");
}



if(distance>=12 && distance<14){
       lcd_Out(1, 1, "Tank: 90% Filled");
}



if(distance<=10){
       lcd_Out(1, 1, "Tank:100% Filled ");
}

   msDelay(500);



   v = ATD_read();
    temp = v* 0.489;
    temp = temp / 5;
    temp = temp - 27;


    if (temp > 99)
      Temperature[0]  = 1 + 48;

    else
    Temperature[0]  = ' ';
    Temperature[1]  = (temp/ 10) % 10  + 48;
    Temperature[2]  =  temp % 10  + 48;
    Temperature[5] = 223;
    lcd_Out(2, 1, Temperature);
     msDelay(500);



  }

}

void ATD_init(void){
 ADCON0 = 0x49;  // ATD ON, Don't GO, Channel 1, Fosc/16           // 01001001
 ADCON1 = 0xC0;  // All channels Analog, right justified          // 11000000
 TRISA = 0xFF;

}
unsigned int ATD_read(void){
  ADCON0 = ADCON0 | 0x04;// GO
  while(ADCON0 & 0x04);
  return((ADRESH<<8) | ADRESL);
}

void usDelay(unsigned int usCnt){
unsigned int us=0;

for(us=0;us<usCnt;us++){
asm NOP;
asm NOP;
}
}

void msDelay(unsigned int msCnt){
unsigned int ms=0;
unsigned int cc=0;

for(ms=0;ms<msCnt;ms++){
for(cc=0;cc<155;cc++);
}
}